<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<h2>欢迎使用Ctrip SDK For PHP 2.0</h2>
<p>请先<a href="install/">设置配置项</a></p>
<p>或者打开doc目录下，阅读我们的文档</p>
<p>或者参考<a href="example/">示例</a></p>
</body>
</html>
